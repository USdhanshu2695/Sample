

object MultiThreading extends App {
  
//  val aThread =new Thread(new Runnable{
//    
//    override def run():Unit=println("I'm running in parallel")
//    
//  })
  val aThread =new Thread(()=>println("I'm running in parallel"))

  
}