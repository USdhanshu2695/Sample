package part2package


  import akka.http.scaladsl.model.{HttpEntity, StatusCodes}
import akka.http.scaladsl.server.{HttpApp, Route}

object AkkaHr extends HttpApp with App {

override protected def routes: Route =
    path("apps") {
      post {
        entity(as[HttpEntity]) { entity =>
          System.out.println("Suds"+entity)
          complete("Hello")
        }
      }
    }

  startServer("localhost", 8080)
}