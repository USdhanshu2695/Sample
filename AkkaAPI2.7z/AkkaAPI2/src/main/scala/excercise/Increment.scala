package excercise

import akka.actor.ActorSystem
import akka.actor.Actor
import akka.actor.Props

object Increment {
  def main(args: Array[String]) {
    val actorSystem = ActorSystem("FirstActor")

    class Exercise extends Actor {
  var balance=10000
      def receive: PartialFunction[Any, Unit] = {

        case moneyWithdrawal(amount) => balance =balance -  amount
        case moneyDeposit(amount) =>  balance  =balance + amount
        case "Print"     => print(balance)
      }

    }
    case class moneyWithdrawal(amount:Int)
       case class moneyDeposit(amount:Int)
    val BankAccount1 = actorSystem.actorOf(Props[Exercise], "Actor1")
       val BankAccount2 = actorSystem.actorOf(Props[Exercise], "Actor2")
    BankAccount1 !moneyWithdrawal(2)
    BankAccount2 ! moneyDeposit(125)
     BankAccount1 !moneyWithdrawal(2)
    BankAccount2 ! moneyDeposit(125)
    BankAccount1 ! "Print"
  }

}