package part2package

import akka.actor.ActorSystem
import akka.http.scaladsl.Http
import akka.http.scaladsl.server.Route
import akka.stream.ActorMaterializer

import akka.actor.{ ActorSystem, Props }
import akka.http.scaladsl.server.Directives._
import akka.http.scaladsl.server.Route
import akka.http.scaladsl.server.directives.RouteDirectives.complete
import akka.util.Timeout
import akka.pattern.ask

import scala.concurrent.Await
import scala.concurrent.duration._
import akka.actor.ActorRef
import akka.http.scaladsl.server.ConjunctionMagnet
import javax.management.QueryEval
import javax.management.QueryExp
import akka.actor.Actor
import java.util.concurrent.TimeUnit
import akka.actor.Scheduler

//import akka.http.javadsl.model.Query

object ApiApp {

  def main(args: Array[String]) {

    implicit val system: ActorSystem = ActorSystem("RESTHttpServer")
    implicit val materializer: ActorMaterializer = ActorMaterializer()

    println("Active Port found.! \nServer running at Port : 8081...")

    class SimpleActor extends Actor {

      def receive: PartialFunction[Any, Unit] = {
        case "hi"                                       => sender() ! "Hello"
        case message: String                            => println(s"From $sender I have received your message $message")
        case number: Int                                => println(s"I have received your number $number")

        case SayHi(ref)                                 => (ref ! "HI")
        case SayForward(content: String, ref: ActorRef) => ref forward (content)
      }
    }

    case class SayHi(ref: ActorRef)
    case class SayForward(content: String, ref: ActorRef)

    val tinu = system.actorOf(Props[SimpleActor], "SimpleActor")
    val minu = system.actorOf(Props[SimpleActor], "SimpleActorw")
    implicit val timeout = Timeout(5 seconds)

    lazy val routing: Route =

      //      path("readviaactor"){
      //        get{
      //          val data = dataactor ? ServicesApiImpl
      //          val result = Await.result(data, timeout.duration).asInstanceOf[String]
      //          complete(StringToJsonData(result))
      //
      //        }
      //      }~
      //    (get & path("insertintodbs"/name)) {name: String
      //     // parameters('name.as[String]){ n =>print(n)}
      //     parameter('color) { color =>
      // print($color)}
      //
      //        tinu ? SayForward("${propName}", minu)
      //        complete { "Data Inserted" }
      //
      //    }
      /**
       *  userId: String =>
       * {
       * print("userId :: " + userId)
       * tinu ? SayForward("hello", minu)
       * complete { "Data Inserted" }
       *
       * }
       *
       */

      get {
        path("insertintodbs") {
          // optional parameters
          parameters('name, 'topic.?) {
            (name, topic) =>
              {
                val backgroundStr = topic.getOrElse("<undefined>")
                complete(backgroundStr)
              }
          }
        }
      } ~
        get {
          path("insertintodbs1") {
            // default parameters
            parameters('name, 'topic ? "Default value") {
              (name, topic) =>
                {
                  complete(topic)
                }
            }
          }
        } ~
        get {
          // Segment
          path("newpath" / Segment) { name: String =>
            complete(name)
          }
        } ~
        (post & path("insertintodbs")) {
          val data = tinu ? SayHi(minu)
          import scala.concurrent.ExecutionContext.Implicits.global
          system.scheduler.scheduleOnce(15 seconds, tinu, 1234)
         // system.startTime
         //Scheduler.schedule(tinu, SayForward("Hello",minu), 0L, 5L, TimeUnit.MINUTES)
          
          complete { "Data Inserted by post" }

        }

    //   (post & path("insertinto")&  Query("contenId=123")){
    //
    //       val e =Query.apply("contenId")
    //          val data =  tinu ?SayForward("$e",minu)
    //          complete{"Data Inserted$e"}
    //        }
    lazy val routes: Route = routing

    Http().bindAndHandle(routes, "localhost", 8081)

  }
}
