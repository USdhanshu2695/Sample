package part2package

import akka.actor.Actor
import akka.actor.ActorSystem
import akka.actor.Props
import akka.actor.ActorRef

object ActorCapabilities extends App{
  
class SimpleActor extends Actor{
  
    def receive:PartialFunction[Any,Unit]={
      case "hi"=>sender()!"Hello"
      case message:String =>println(s"From $sender I have received your message $message")
      case number : Int =>println(s"I have received your number $number")
      case SupportActors(contents)=>println(s"I have received something special $contents")
      case SendActors(content)=>self !content
    case SayHi(ref)=>(ref !"HI")
    case SayForward(content:String,ref:ActorRef)=>ref forward( content)
    }
}
val actorSystem=ActorSystem("FirstActor1")
val actor=actorSystem.actorOf(Props[SimpleActor],"actor1")
case class SupportActors(content:String)
case class SendActors(content:String)
//actor !  SupportActors("some Special message")
//actor !  SendActors("I  am an Actor and I am proud of it")
val tinu=actorSystem.actorOf(Props[SimpleActor],"tinu")
val minu=actorSystem.actorOf(Props[SimpleActor],"minu")
case class SayHi(ref:ActorRef)
case class SayForward(content:String,ref:ActorRef)

 tinu ! SayHi(minu)
 tinu !SayForward("Hello",minu)
}